# Decoder — Learn. Code. Get Placed.

Static website, no build step, no dependencies.

## Run
Open `index.html` in a browser, or serve the folder:

    python3 -m http.server 8000   # then visit http://localhost:8000

## Structure
- index.html — markup
- css/style.css — styles
- js/app.js — all app logic (hash-based routing, tools, dashboard)
- decoder-single-file.html — the original all-in-one version (works standalone)

## Deploy
Upload the folder to any static host (Netlify, Vercel, GitHub Pages, Cloudflare Pages).
